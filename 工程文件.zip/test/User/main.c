#include "stm32f10x.h"
#include "led.h"


/*void Delay(u32 count)
{
		u32 i=0;
		for(;i<count;i++);
}*/


int main(void)
{

	LED_GPIO_Config();
	while(1)
	{
		//GPIO_ResetBits(GPIOB, GPIO_Pin_5);
		LedControl(ON);
		//Delay(1000000);
		//GPIO_SetBits(GPIOB, GPIO_Pin_5);
		LedControl(OFF);
		//Delay(1000000);
	}
}
 

